import{a as y,b as S,g as w,u as T,e as _,n as g,p as C,d as A}from"./ai-config-BEok2NJA.js";import{c as M,a as v}from"./link-checker-CNl7dCbL.js";const p=new Map,b=5*60*1e3,E=50;async function $(e,o,r,t=20){const s=e.trim();if(!s)return{results:[],query:e,totalMatches:0,usage:null,cached:!1};if(o.length===0)return{results:[],query:e,totalMatches:0,usage:null,cached:!1};const c=`${s}:${r||"default"}`,a=p.get(c);if(a&&Date.now()-a.timestamp<b)return{results:a.results.slice(0,t),query:s,totalMatches:a.results.length,usage:null,cached:!0};const n=await y(r||null);S(n);const i=await w(),h=String((i==null?void 0:i.language)||"").toLowerCase().startsWith("en"),m=B(s,o,h,t),u=await I(n,m,.3,3e4,h?"You are a bookmark search assistant. Analyze the user query and return the most relevant bookmarks with relevance scores. Output strict JSON only.":"你是书签搜索助手。分析用户查询并返回最相关的书签及相关度评分。只输出严格的 JSON。");u.usage&&await T(n.id,d=>{d.totalRequests++,d.totalPromptTokens+=u.usage.prompt_tokens||0,d.totalCompletionTokens+=u.usage.completion_tokens||0,d.totalTokens+=u.usage.total_tokens||0,d.lastUsed=g(),C(d,{time:g(),promptTokens:u.usage.prompt_tokens||0,completionTokens:u.usage.completion_tokens||0,totalTokens:u.usage.total_tokens||0})});const f=_(u.content),k=O(f,o,t);return K(c,k),{results:k.slice(0,t),query:s,totalMatches:k.length,usage:u.usage,cached:!1}}function B(e,o,r,t){const s=Math.min(200,o.length),a=(o.length>s?x(o,s):o).map((n,i)=>`${i+1}. id=${n.id} | title=${N(n.title)} | url=${L(n.url)}`).join(`
`);return r?`Find bookmarks matching this search query: "${e}"

Return the most relevant bookmarks (up to ${t}) with relevance scores.

Output STRICT JSON only (no markdown):
{
  "matches": [
    {
      "id": "bookmark_id",
      "relevanceScore": 95,
      "reason": "Brief explanation why this matches"
    }
  ]
}

Rules:
1. relevanceScore: 0-100 (100 = perfect match, 0 = no match)
2. Only include bookmarks with score >= 30
3. Sort by relevanceScore descending
4. reason: Short explanation (max 100 chars) based on title/domain/keywords
5. Consider semantic meaning, not just exact keyword matches
6. If query is in Chinese, match Chinese bookmarks; if English, match English bookmarks

Bookmarks:
${a}`:`查找与此搜索查询匹配的书签："${e}"

返回最相关的书签（最多 ${t} 个）及相关度评分。

只输出严格 JSON（不要 markdown）：
{
  "matches": [
    {
      "id": "书签ID",
      "relevanceScore": 95,
      "reason": "简短说明为何匹配"
    }
  ]
}

规则：
1. relevanceScore：0-100（100=完全匹配，0=不匹配）
2. 只包含评分 >= 30 的书签
3. 按 relevanceScore 降序排列
4. reason：简短说明（最多 60 字）基于标题/域名/关键词
5. 考虑语义含义，不仅仅是精确关键词匹配
6. 如果查询是中文，匹配中文书签；如果是英文，匹配英文书签

书签列表：
${a}`}function O(e,o,r){if(!e||typeof e!="object")return[];const t=Array.isArray(e.matches)?e.matches:[],s=new Map(o.map(a=>[a.id,a])),c=[];for(const a of t){const n=String((a==null?void 0:a.id)||"").trim(),i=Number((a==null?void 0:a.relevanceScore)||0),h=String((a==null?void 0:a.reason)||"").trim().slice(0,200);if(!n||i<30)continue;const m=s.get(n);m&&c.push({id:m.id,title:m.title,url:m.url,relevanceScore:Math.min(100,Math.max(0,i)),reason:h||void 0})}return c.sort((a,n)=>n.relevanceScore-a.relevanceScore),c.slice(0,r)}async function I(e,o,r,t,s){var n,i,h;const c=new AbortController,a=setTimeout(()=>c.abort(),t);try{const m=[];s&&m.push({role:"system",content:s}),m.push({role:"user",content:o});const l=await fetch(e.apiEndpoint,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${e.apiKey}`},body:JSON.stringify({model:e.model,messages:m,temperature:r}),signal:c.signal});if(!l.ok){const d=await l.text();throw new Error(`${l.status}: ${d}`)}const u=await l.json(),f=((h=(i=(n=u.choices)==null?void 0:n[0])==null?void 0:i.message)==null?void 0:h.content)||"",k=u.usage||null;return{content:f,usage:k}}finally{clearTimeout(a)}}function N(e){return String(e||"").replace(/\s+/g," ").trim().slice(0,100)}function L(e){try{return new URL(e).hostname}catch{return""}}function x(e,o){const r=[...e].sort((n,i)=>(i.dateAdded||0)-(n.dateAdded||0)),t=r.slice(0,Math.floor(o*.3)),s=r.slice(Math.floor(o*.3)),c=[],a=Math.max(1,Math.floor(s.length/(o-t.length)));for(let n=0;n<s.length&&c.length<o-t.length;n+=a)c.push(s[n]);return[...t,...c]}function K(e,o){var r;if(p.size>=E){const t=(r=Array.from(p.entries()).sort((s,c)=>s[1].timestamp-c[1].timestamp)[0])==null?void 0:r[0];t&&p.delete(t)}p.set(e,{results:o,timestamp:Date.now()})}chrome.runtime.onInstalled.addListener(e=>{e.reason==="install"?(console.log("BookMarkMap installed"),chrome.storage.sync.set({settings:A()})):e.reason==="update"&&console.log("BookMarkMap updated to",chrome.runtime.getManifest().version)});chrome.runtime.onMessage.addListener((e,o,r)=>{switch(e.type){case"CHECK_LINK":return v(e.url).then(t=>r(t)).catch(t=>r({error:t.message})),!0;case"CHECK_LINKS_BATCH":return M(e.bookmarks).then(t=>r({results:t})).catch(t=>r({error:t.message})),!0;case"AI_SEARCH_BOOKMARKS":return $(e.query,e.bookmarks,e.configId,e.maxResults).then(t=>r(t)).catch(t=>r({error:t.message})),!0;case"TEST_AI_CONNECTION":return H(e.configId).then(t=>r(t)).catch(t=>r({error:t.message})),!0;case"GET_SETTINGS":return w().then(t=>r({settings:t})).catch(t=>r({error:t.message})),!0;case"SAVE_SETTINGS":return chrome.storage.sync.set({settings:e.settings},()=>{r({success:!0})}),!0;default:r({error:"Unknown message type"})}});async function H(e){var i,h,m;const o=await y(e||null);S(o);const r=Date.now(),t=await fetch(o.apiEndpoint,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${o.apiKey}`},body:JSON.stringify({model:o.model||"gpt-3.5-turbo",messages:[{role:"user",content:'Hi, this is a connection test. Reply with "OK".'}],max_tokens:10})}),s=Date.now()-r;if(!t.ok){const l=await t.text();throw new Error(`${t.status}: ${l}`)}const c=await t.json(),a=((m=(h=(i=c.choices)==null?void 0:i[0])==null?void 0:h.message)==null?void 0:m.content)||"",n=c.usage||null;return n&&await T(o.id,l=>{l.totalRequests++,l.totalPromptTokens+=n.prompt_tokens||0,l.totalCompletionTokens+=n.completion_tokens||0,l.totalTokens+=n.total_tokens||0,l.lastUsed=g(),C(l,{time:g(),promptTokens:n.prompt_tokens||0,completionTokens:n.completion_tokens||0,totalTokens:n.total_tokens||0})}),{success:!0,reply:a.trim(),elapsed:s,model:o.model,usage:n}}chrome.bookmarks.onCreated.addListener((e,o)=>{console.log("Bookmark created:",o.title)});chrome.bookmarks.onRemoved.addListener(e=>{console.log("Bookmark removed:",e)});chrome.bookmarks.onChanged.addListener((e,o)=>{console.log("Bookmark changed:",e,o)});chrome.bookmarks.onMoved.addListener((e,o)=>{console.log("Bookmark moved:",e,o)});
