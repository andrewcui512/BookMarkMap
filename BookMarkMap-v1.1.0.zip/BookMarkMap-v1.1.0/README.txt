BookMarkMap Installation Guide
==============================

Thank you for using BookMarkMap!

## Installation Steps

1. Open Chrome browser
2. Enter in address bar: chrome://extensions/
3. Enable "Developer mode" toggle in the top right
4. Click "Load unpacked"
5. Select this folder (BookMarkMap-vX.X.X)
6. Done! Click the extension icon in toolbar to use

## Features

- 📚 Tree structure bookmark management
- 🗺️ Mind map visualization
- 🤖 AI-powered search (requires AI service configuration)
- 🔍 Broken link detection

## AI Search Configuration

1. Click extension icon to open Popup
2. Click "⚙️ Settings" in top right
3. Add your AI service in "AI Configuration" section
4. Supports: Kimi, DeepSeek, GLM, Custom OpenAI-compatible endpoints
5. After configuration, switch to "AI" mode in search box

## Notes

- This extension requires "Developer mode" to load
- If Chrome shows "Extensions may be disabled soon", ignore it - this is normal
- Recommended to install from Chrome Web Store when available (no developer mode needed)

## Privacy

- All data stored locally
- No user behavior tracking
- AI search only uses your configured endpoint
- Privacy policy: https://github.com/yourusername/BookMarkMap/blob/main/privacy.md

## Feedback

GitHub: https://github.com/yourusername/BookMarkMap/issues

Enjoy!
